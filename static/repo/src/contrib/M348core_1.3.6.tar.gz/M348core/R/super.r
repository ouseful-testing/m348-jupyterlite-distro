#' Numbers of supervisors and supervised workers
#'
#' The number of supervisors and the number of supervised workers obtained from 
#' a survey of 27 successful industrial establishments from the same sector 
#' but of varying size.
#'
#' @format A data frame with 27 rows and 2 variables:
#' \describe{
#'   \item{y}{Number of supervisors in the industrial establishment}
#'   \item{x}{Number of workers in the industrial establishment}
#' }
#'
#' @usage data(super)

"super"
