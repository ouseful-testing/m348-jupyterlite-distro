library(testit)
test_pkg('formatR')
