#' Attributes of possum
#'
#' In a study of common brushtail possums in Australia, 101 adult possums 
#' across 7 regions were trapped, and their length and weight measurements were taken. 
#'
#' @format A data frame with 101 rows and 3 variables:
#' \describe{
#'   \item{weight}{weight of the possum (kg)}
#'   \item{length}{length of the possum including the tail (cm)}
#'   \item{location}{region the possum was captured \((1, 2, ..., 7)\)}
#' }
#'
#' @usage data(possum)

"possum"
