#' A function to calculate the derivative of a log-likelihood
#'
#' @param p the binomial probability
#' @param n the total number of observations
#' @param sy the number of successes
#'
#' @return the value of the derviative
#'
#' @author Karen Vines
#' 
#' @export


lDash <- function(p,n=n, sy=sy){
	value <- sy/p - (n-sy)/(1-p)
	value
}
