#' Do wages show money illusion
#'
#' A time series with 133 observations, over the period 1855-1987, for a fictitious country
#'
#' @format A data frame with 133 rows and 6 variables:
#' \describe{
#'   \item{year}{the year the observation relates to}
#'   \item{moneyWage}{the wages in nominal terms, logged}
#'   \item{priceLevel}{the general level of prices, logged}
#'   \item{gdp}{the log of GDP expressed in real terms}
#'   \item{employment}{the total number of workers employed, logged}
#'   \item{labForce}{the total size of the labour force, logged.}
#' }
#'
#' @source Koop, G. (2005) Analysis of Economic data. 2nd edition.Chichester: John Wiley and Sons Ltd.)
#'
#' @usage data(wage)

"wage"
