.getLibs <- function(){
#	library(M348core)
#	library(M348lite)
}
