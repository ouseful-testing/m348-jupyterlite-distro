.plotdevice <- function(...){
	grDevices::png(...)
	grDevices::dev.control("enable")
}
