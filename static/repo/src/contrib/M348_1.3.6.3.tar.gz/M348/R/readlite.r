#' A function to read .csv files wherever they are in the Jupyterlite environment
#'
#' @param filename the name of the file to be read in
#' @param use_browser_storage indicator of whether to look in browser storage
#' @param verbose should details about where files be given?
#'
#' @return a data frame containing the contents of the file
#'
#' @author Karen Vines
#' 
#' @export


read.csv <- function(filename, use_browser_storage = FALSE, verbose=F) {
	# Check if filename is already a URL (matches http:// or https://)
	if (!grepl("^https?://", filename)) {
	# Ensure PORTNUMBER is defined
		if (!exists("PORTNUMBER")) {
			errMess <- c("PORTNUMBER has not yet been defined. Suggest setting it using the command 'initialise(PORTNUMBER = 8348)'.\n")
			stop(errMess)
		}

	# Choose path based on use_browser_storage flag
	# By default, use the /share/ which looks to files in USERDIR/M348-24J
		path_prefix <- ifelse(use_browser_storage, "/files/", "/share/")
		full_path <- paste0("http://localhost:", PORTNUMBER, path_prefix, filename)

	# Try reading the file from the /share/ path
		tryCatch({
			data <- utils::read.csv(full_path)
			if (path_prefix=="/files/") {
				if (verbose) message("Reading from local browser storage.")
				if (verbose) message("To persist this data file you will need to download it from the main, rather than Local File System, directory listing, to your shared M348-24J directory.")
			} else {
				if (verbose) message("Reading file from shared 'M348-24J' directory.")
			}
			return(data)	# If successful, return the data
			}, error = function(e) {
			if (path_prefix=="/share/") {
				if (verbose) message("File not found in shared directory 'M348-24J' in your desktop computer user directory")
				if (verbose) message("Trying local browser storage...")
				path_prefix <- "/files/"
				full_path <- paste0("http://localhost:", PORTNUMBER, path_prefix, filename)

				# Try reading from /files/ path
				tryCatch({
					data <- utils::read.csv(full_path)	# If this fails, let the error propagate
					if (verbose) message("File found in browser storage. To persist this data file you will need to download it from the main, rather than Local File System, directory listing, to your shared M348-24J directory.")
					return(data)
					}, error=function(e) {
					if (verbose) message("File not found in browser storage ")
				})
			} else {
				if (verbose) message("File not found in browser storage / main Jupyter browser listing.")
			}
		})
	} else {
		# If it's a URL, use it directly
		data <- utils::read.csv(filename)
		return(data)
	}
}

