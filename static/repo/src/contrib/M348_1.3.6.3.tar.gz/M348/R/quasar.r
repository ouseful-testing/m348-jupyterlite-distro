#' Characteristics of quasars
#'
#' In a study of quasars detected by a deep space survey, 24 large (redshift) 
#' quasars were found and 6 different characteristics were recorded. These 
#' different characteristics are shown below in the description of the 
#' variables in the dataset.
#'
#' @format A data frame with 24 rows and 6 variables:
#' \describe{
#'   \item{x1}{Redshift range}
#'   \item{x2}{Line flux (erg per cm squared)}
#'   \item{x3}{Line luminosity (erg per s)}
#'   \item{x4}{AB1450 magnitude}
#'   \item{x5}{Absolute magnitude}
#'   \item{yLog}{Log-transformation of the rest frame equivalent width}\\
#' }
#'
#' @usage data(quasar)

"quasar"
