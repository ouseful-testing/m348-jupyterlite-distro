# Curvenote Default

A paper styled template using the custom environments and styling to match https://curvenote.com web experience.

![](thumbnail.png)

- Author: Curvenote
- License: CC-BY-4.0
